const btnAdd=document.getElementById('push');         //creating object for button and textbox
const todoInput=document.getElementById('text');
const task=document.getElementById('tasks')


const remove=function(event){
  event.target.parentNode.remove();

}

const createTodo=function(value){

    const todoItem=document.createElement('div');         
    const checkbox=document.createElement('input');
    checkbox.type='checkbox'
    const label= document.createElement('label');
    label.innerText=value;
    
    checkbox.addEventListener('change',remove)

    todoItem.appendChild(checkbox)
    todoItem.appendChild(label)
    return todoItem
    
}

const addToDo= function(event){                //to check whether the button click or not   
  
   event.preventDefault();
   task.appendChild(createTodo(todoInput.value));
   todoInput.value="";                      //to clear the previous data.
}


btnAdd.addEventListener('click',addToDo);     //here we are calling the addtodo function to perform adding elemnt